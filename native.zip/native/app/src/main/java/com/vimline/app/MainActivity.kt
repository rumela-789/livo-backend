package com.vimline.app

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val ui = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val isTv = ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
        setContent {
            VimlineTheme {
                VimlineApp(vm, isTv)
            }
        }
    }
}
