package com.vimline.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.File

data class Channel(
    val name: String,
    val logo: String,
    val urls: List<String>,
    val verified: Boolean = false,
    val mine: Boolean = false,
    val src: String = ""
)

data class Tab(val id: String, val name: String, val channels: List<Channel>)

class Raw(val name: String, val logo: String, val cc: String, val urls: MutableList<String>)

typealias RawMap = Map<String, List<Raw>>

private val ADULT = Regex(
    "\\b(xxx|porn\\w*|sex\\w*|adult|erotic\\w*|playboy|hustler|brazzers|penthouse|nude|nudes|hentai|fetish|18\\+|redlight|vivid)\\b",
    RegexOption.IGNORE_CASE
)
private val ADULT_GROUP = Regex("xxx|adult|porn|erotic", RegexOption.IGNORE_CASE)
private val KOL = Regex(
    "bangla|bengal|jalsha|ananda|kolkata|calcutta|aath|aakash|24 ?ghanta|sangeet|mahuaa",
    RegexOption.IGNORE_CASE
)
private val QUALITY_WORDS = Regex("\\b(hd|sd|fhd|uhd|4k)\\b")
private val NON_ALNUM = Regex("[^a-z0-9\\u0980-\\u09ff]")
private val BRACKETS = Regex("\\s*\\[.*?\\]|\\s*\\(\\d+p\\)")

fun norm(n: String): String = n.lowercase().replace(QUALITY_WORDS, "").replace(NON_ALNUM, "")

private fun attr(line: String, key: String): String {
    val m = Regex("$key=\"([^\"]*)\"").find(line)
    return if (m != null) m.groupValues[1] else ""
}

/** Reads an M3U list. Adult entries are dropped (unless the list is only used as a block list). */
fun parseM3u(text: String, forBlock: Boolean = false): List<Raw> {
    val map = LinkedHashMap<String, Raw>()
    var name = ""
    var logo = ""
    var cc = ""
    var adult = false
    var have = false
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.startsWith("#EXTINF")) {
            val comma = line.indexOf(',')
            name = if (comma >= 0) line.substring(comma + 1).trim() else ""
            name = name.replace(BRACKETS, "").trim()
            logo = attr(line, "tvg-logo")
            val id = attr(line, "tvg-id")
            val grp = attr(line, "group-title")
            cc = if (id.contains('.')) id.substringAfterLast('.').substringBefore('@').lowercase() else ""
            adult = ADULT.containsMatchIn(name) || ADULT_GROUP.containsMatchIn(grp)
            have = true
        } else if (line.isNotEmpty() && !line.startsWith("#") && have) {
            val k = norm(name)
            if (k.isNotEmpty() && (forBlock || (!adult && line.startsWith("http")))) {
                val e = map.getOrPut(k) { Raw(name, logo, cc, mutableListOf()) }
                if (!e.urls.contains(line)) e.urls.add(line)
            }
            have = false
        }
    }
    return map.values.toList()
}

private fun cat(vararg keys: String): (RawMap) -> List<Raw> = { r -> keys.flatMap { r[it] ?: emptyList() } }

class TabDef(val id: String, val name: String, val get: (RawMap) -> List<Raw>)

/** Order matters: a channel is kept only in the first tab that contains it. */
val TAB_DEFS: List<TabDef> = listOf(
    TabDef("bd", "Bangladesh", cat("bd")),
    TabDef("kol", "Kolkata") { r ->
        (r["ben"] ?: emptyList()).filter { it.cc != "bd" } + (r["in"] ?: emptyList()).filter { KOL.containsMatchIn(it.name) }
    },
    TabDef("sports", "Sports", cat("sports")),
    TabDef("movies", "Movies", cat("movies")),
    TabDef("music", "Music", cat("music")),
    TabDef("news", "News", cat("news")),
    TabDef("kids", "Kids", cat("kids", "animation")),
    TabDef("ent", "Entertainment", cat("entertainment", "comedy", "series", "classic")),
    TabDef("life", "Lifestyle", cat("lifestyle", "cooking", "travel", "outdoor", "family")),
    TabDef("know", "Knowledge", cat("documentary", "science", "culture", "education")),
    TabDef("rel", "Religious", cat("religious")),
    TabDef("hin", "Hindi", cat("hin")),
    TabDef("sa", "South Asia", cat("pk", "np", "lk")),
    TabDef("intl", "International", cat("us", "gb", "general", "business", "weather"))
)

object Repo {
    private const val B = "https://iptv-org.github.io/iptv/"
    private const val LIST_TTL = 3 * 3600 * 1000L

    private val FILES: Map<String, String> = linkedMapOf(
        "bd" to "countries/bd", "ben" to "languages/ben", "in" to "countries/in", "hin" to "languages/hin",
        "sports" to "categories/sports", "movies" to "categories/movies", "music" to "categories/music",
        "news" to "categories/news", "us" to "countries/us", "gb" to "countries/gb",
        "pk" to "countries/pk", "np" to "countries/np", "lk" to "countries/lk",
        "kids" to "categories/kids", "animation" to "categories/animation",
        "entertainment" to "categories/entertainment", "comedy" to "categories/comedy",
        "series" to "categories/series", "classic" to "categories/classic",
        "documentary" to "categories/documentary", "science" to "categories/science",
        "culture" to "categories/culture", "religious" to "categories/religious",
        "education" to "categories/education", "lifestyle" to "categories/lifestyle",
        "cooking" to "categories/cooking", "travel" to "categories/travel",
        "outdoor" to "categories/outdoor", "family" to "categories/family",
        "general" to "categories/general", "business" to "categories/business",
        "weather" to "categories/weather"
    )

    private fun fetchCached(ctx: Context, key: String, url: String, force: Boolean): String? {
        val f = File(ctx.filesDir, "cache_$key.m3u")
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < LIST_TTL) {
            return f.readText()
        }
        return try {
            val s = Net.getString(url)
            f.writeText(s)
            s
        } catch (e: Exception) {
            if (f.exists()) f.readText() else null
        }
    }

    suspend fun loadTabs(ctx: Context, force: Boolean): List<Tab> = coroutineScope {
        val keys = FILES.keys.toList()
        val jobs = keys.map { k ->
            async(Dispatchers.IO) {
                val text = fetchCached(ctx, k, B + FILES[k] + ".m3u", force)
                Pair(k, if (text != null) parseM3u(text) else emptyList())
            }
        }
        val blockJob = async(Dispatchers.IO) {
            // The adult list is downloaded ONLY so that its channels can be removed everywhere.
            val text = fetchCached(ctx, "xxx", B + "categories/xxx.m3u", force)
            if (text != null) parseM3u(text, true) else emptyList()
        }
        val raw: RawMap = jobs.awaitAll().toMap()
        val block = blockJob.await()
        val blockNames = block.map { norm(it.name) }.toHashSet()
        val blockUrls = block.flatMap { it.urls }.toHashSet()

        val seen = HashMap<String, MutableList<String>>()
        val tabs = ArrayList<Tab>()
        for (def in TAB_DEFS) {
            val list = ArrayList<Pair<Raw, MutableList<String>>>()
            for (c in def.get(raw)) {
                val k = norm(c.name)
                if (k.isEmpty() || ADULT.containsMatchIn(c.name) || blockNames.contains(k)) continue
                if (c.urls.any { blockUrls.contains(it) }) continue
                val existing = seen[k]
                if (existing != null) {
                    for (u in c.urls) if (!existing.contains(u)) existing.add(u)
                } else {
                    val urls = c.urls.toMutableList()
                    seen[k] = urls
                    list.add(Pair(c, urls))
                }
            }
            tabs.add(Tab(def.id, def.name, list.map { (c, urls) -> Channel(c.name, c.logo, urls) }))
        }
        tabs
    }
}
