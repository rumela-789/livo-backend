package com.vimline.app

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import coil.compose.SubcomposeAsyncImage
import kotlinx.coroutines.delay

/* ---- calm, eye-friendly palette: deep teal-black, soft cream text, warm gold accent ---- */
val Bg = Color(0xFF0B1519)
val Panel = Color(0xFF122229)
val Panel2 = Color(0xFF173038)
val Line = Color(0x33E8E4DA)
val Txt = Color(0xFFE8E4DA)
val Dim = Color(0xFF8FA1A6)
val Gold = Color(0xFFF6AD4A)

@Composable
fun VimlineTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Color.Black,
            background = Bg, onBackground = Txt,
            surface = Panel, onSurface = Txt
        ),
        content = content
    )
}

@Composable
fun VimlineApp(vm: MainViewModel, isTv: Boolean) {
    val activity = LocalContext.current as Activity
    val playing = vm.player != null

    BackHandler(enabled = playing) { vm.closePlayer() }

    LaunchedEffect(playing) {
        val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (playing) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (isTv) TvHome(vm) else PhoneHome(vm)
        if (playing) PlayerScreen(vm, isTv)
    }
}

/* ---------------------------------------------------------------- pieces */

@Composable
fun Initial(c: Channel, size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Bg).border(1.dp, Line, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(c.name.take(1).uppercase(), color = Dim, fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Logo(c: Channel, size: Dp) {
    if (c.logo.isNotBlank()) {
        SubcomposeAsyncImage(
            model = c.logo,
            contentDescription = null,
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit,
            loading = { Initial(c, size) },
            error = { Initial(c, size) }
        )
    } else {
        Initial(c, size)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChannelCard(c: Channel, isTv: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "focusScale")
    val shape = RoundedCornerShape(if (isTv) 24.dp else 20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .height(if (isTv) 150.dp else 108.dp)
            .scale(scale)
            .clip(shape)
            .background(if (focused) Color.Black else Panel2)
            .border(2.dp, if (focused) Gold else Line, shape)
            .onFocusChanged { focused = it.isFocused }
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo(c, if (isTv) 64.dp else 44.dp)
        Spacer(Modifier.height(8.dp))
        Text(
            c.name, color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, fontSize = if (isTv) 17.sp else 12.sp, lineHeight = if (isTv) 21.sp else 15.sp
        )
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(14.dp)).background(Panel2).border(1.dp, Line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Txt, fontSize = 14.sp) }
}

@Composable
fun TabPill(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Panel2 else Color.Transparent)
            .border(1.dp, if (selected) Gold else Line, shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(text, color = if (selected) Txt else Dim, fontSize = 14.sp) }
}

@Composable
fun TvButton(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.fillMaxWidth().clip(shape)
            .background(if (focused) Color.Black else if (selected) Panel2 else Color.Transparent)
            .border(2.dp, if (focused) Gold else if (selected) Line else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) { Text(text, color = if (focused || selected) Txt else Dim, fontSize = 20.sp) }
}

/* ----------------------------------------------------------------- phone */

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PhoneHome(vm: MainViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    var delSrc by remember { mutableStateOf<String?>(null) }
    val allTabs = vm.tabs.map { Pair(it.id, it.name) } + Pair("mine", "My links")
    val list = if (vm.query.isBlank()) vm.visible.toList() else vm.visible.filter { it.name.contains(vm.query, ignoreCase = true) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vimline", color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp)
            Spacer(Modifier.weight(1f))
            Pill("Refresh") { vm.load(true) }
            Spacer(Modifier.width(8.dp))
            Pill("+") { showAdd = true }
        }
        BasicTextField(
            value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
            textStyle = TextStyle(color = Txt, fontSize = 15.sp), cursorBrush = SolidColor(Gold),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(42.dp)
                .clip(RoundedCornerShape(14.dp)).background(Panel).padding(horizontal = 14.dp),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (vm.query.isEmpty()) Text("Search channels", color = Dim, fontSize = 15.sp)
                    inner()
                }
            }
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(allTabs.size) { i ->
                val t = allTabs[i]
                TabPill(t.second, vm.currentTab == t.first) { vm.selectTab(t.first) }
            }
        }
        Text(vm.status, color = Dim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(list) { c ->
                ChannelCard(c, false, onClick = { vm.openChannel(c) }, onLong = { if (c.mine) delSrc = c.src })
            }
        }
    }

    if (showAdd) AddDialog(onDismiss = { showAdd = false }, onAdd = { n, u -> vm.addCustom(n, u); showAdd = false })

    val d = delSrc
    if (d != null) {
        AlertDialog(
            onDismissRequest = { delSrc = null },
            title = { Text("Delete this link?") },
            text = { Text("The link and its channels will be removed from My links.") },
            confirmButton = { TextButton(onClick = { vm.removeCustom(d); delSrc = null }) { Text("Delete", color = Gold) } },
            dismissButton = { TextButton(onClick = { delSrc = null }) { Text("Cancel", color = Txt) } }
        )
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a link") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name (optional)") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, singleLine = true, label = { Text("M3U playlist or .m3u8 link") })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (url.trim().startsWith("http")) onAdd(name.trim(), url.trim()) }) { Text("Add", color = Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Txt) } }
    )
}

/* -------------------------------------------------------------------- TV */

@Composable
fun TvHome(vm: MainViewModel) {
    val first = remember { FocusRequester() }
    val allTabs = vm.tabs.map { Pair(it.id, it.name) }
    LaunchedEffect(vm.tabs.size) {
        if (vm.tabs.isNotEmpty()) {
            delay(200)
            try { first.requestFocus() } catch (e: Exception) { }
        }
    }
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier.width(270.dp).fillMaxHeight().background(Panel).padding(horizontal = 18.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Vimline", color = Txt, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp))
            TvButton("Refresh", false) { vm.load(true) }
            TvButton("Fast zap: " + if (vm.fast) "On" else "Off", false) { vm.toggleFast() }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(allTabs) { i, t ->
                    TvButton(t.second, vm.currentTab == t.first, if (i == 0) Modifier.focusRequester(first) else Modifier) { vm.selectTab(t.first) }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(start = 24.dp, end = 24.dp, top = 20.dp)) {
            Text(vm.status, color = Dim, fontSize = 18.sp, modifier = Modifier.padding(bottom = 10.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(200.dp),
                contentPadding = PaddingValues(bottom = 60.dp, top = 8.dp, start = 6.dp, end = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(vm.visible.toList()) { c ->
                    ChannelCard(c, true, onClick = { vm.openChannel(c) }, onLong = { })
                }
            }
        }
    }
}

/* ---------------------------------------------------------------- player */

private fun handleKey(vm: MainViewModel, e: KeyEvent): Boolean {
    val down = e.type == KeyEventType.KeyDown
    return when (e.key) {
        Key.DirectionDown, Key.ChannelDown -> { if (down) vm.zap(1); true }
        Key.DirectionUp, Key.ChannelUp -> { if (down) vm.zap(-1); true }
        Key.DirectionRight -> { if (down) vm.cycleQuality(1); true }
        Key.DirectionLeft -> { if (down) vm.cycleQuality(-1); true }
        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { if (down) vm.toggleOverlay(); true }
        else -> false
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel, isTv: Boolean) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { fr.requestFocus() } catch (e: Exception) { } }
    LaunchedEffect(vm.overlayTick) {
        delay(5000)
        vm.overlay = false
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(fr)
            .onPreviewKeyEvent { handleKey(vm, it) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.toggleOverlay() }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    keepScreenOn = true
                }
            },
            update = { it.player = vm.player },
            modifier = Modifier.fillMaxSize()
        )
        if (vm.toast.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(24.dp).clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC000000)).padding(horizontal = 18.dp, vertical = 10.dp)
            ) { Text(vm.toast, color = Txt, fontSize = if (isTv) 20.sp else 14.sp) }
        }
        AnimatedVisibility(visible = vm.overlay, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.align(Alignment.BottomCenter)) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .padding(horizontal = if (isTv) 48.dp else 20.dp, vertical = if (isTv) 32.dp else 18.dp)
            ) {
                Spacer(Modifier.height(30.dp))
                Text(vm.playingChannel?.name ?: "", color = Txt, fontSize = if (isTv) 36.sp else 22.sp, fontWeight = FontWeight.SemiBold)
                Text(vm.playStatus, color = Gold, fontSize = if (isTv) 20.sp else 14.sp)
                if (isTv) {
                    Text(
                        "Up / Down: change channel   ·   Left / Right: quality   ·   OK: show or hide this bar   ·   Back: list",
                        color = Dim, fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                } else {
                    Row(Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("‹ Prev") { vm.zap(-1) }
                        Pill("Next ›") { vm.zap(1) }
                        for (h in vm.qualities) {
                            TabPill(if (h < 0) "Auto" else "${h}p", vm.selectedQ == h) { vm.setQuality(h) }
                        }
                    }
                }
            }
        }
    }
}
