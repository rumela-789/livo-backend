package com.vimline.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/* ------------------------------------------------------------------ network */

object Net {
    private const val UA = "Mozilla/5.0 (Linux; Android 11) Vimline"
    lateinit var app: Context

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private val big: OkHttpClient = client.newBuilder()
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    fun online(): Boolean {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun getString(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        return big.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw java.io.IOException("HTTP " + r.code)
            r.body!!.string()
        }
    }

    /** Reads at most [max] bytes from the start of [url]; null when the server refuses. */
    fun getBytes(url: String, max: Int): ByteArray? {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        return client.newCall(req).execute().use { r -> readUpTo(r, max) }
    }

    private fun readUpTo(r: okhttp3.Response, max: Int): ByteArray? {
        if (!r.isSuccessful) return null
        val body = r.body ?: return null
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        val ins = body.byteStream()
        while (out.size() < max) {
            val n = ins.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}

/* ------------------------------------------------------------------ storage */

data class Custom(val name: String, val url: String, val type: String)

object Store {
    private lateinit var sp: SharedPreferences
    private const val HIDE_MS = 3600 * 1000L

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.getSharedPreferences("vimline", Context.MODE_PRIVATE)
    }

    private fun hiddenObj(): JSONObject = try { JSONObject(sp.getString("hidden", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun isHidden(key: String): Boolean {
        val t = hiddenObj().optLong(key, 0L)
        return t > 0 && System.currentTimeMillis() - t < HIDE_MS
    }

    fun hide(key: String) {
        val o = hiddenObj()
        o.put(key, System.currentTimeMillis())
        sp.edit().putString("hidden", o.toString()).apply()
    }

    fun clearHidden() {
        sp.edit().remove("hidden").apply()
    }

    var fast: Boolean
        get() = sp.getBoolean("fast", true)
        set(v) { sp.edit().putBoolean("fast", v).apply() }

    fun customs(): List<Custom> {
        val out = ArrayList<Custom>()
        try {
            val a = JSONArray(sp.getString("custom", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Custom(o.optString("name"), o.optString("url"), o.optString("type")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun saveCustoms(list: List<Custom>) {
        val a = JSONArray()
        for (c in list) a.put(JSONObject().put("name", c.name).put("url", c.url).put("type", c.type))
        sp.edit().putString("custom", a.toString()).apply()
    }

    fun addCustom(c: Custom) { saveCustoms(customs() + c) }
    fun removeCustom(url: String) { saveCustoms(customs().filter { it.url != url }) }

    fun loadAlive(): String? = sp.getString("alive", null)
    fun saveAlive(json: String) { sp.edit().putString("alive", json).apply() }
}

/* ------------------------------------------------------------ link checking */

object AliveCache {
    private const val TTL = 3 * 3600 * 1000L
    private const val BAD_TTL = 15 * 60 * 1000L
    private val ok = ConcurrentHashMap<String, Long>()
    private val bad = ConcurrentHashMap<String, Long>()
    private val soft = ConcurrentHashMap<String, Boolean>()

    fun restore() {
        try {
            val o = JSONObject(Store.loadAlive() ?: return)
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                ok[k] = o.getLong(k)
            }
        } catch (e: Exception) { }
    }

    fun persist() {
        val now = System.currentTimeMillis()
        val o = JSONObject()
        for ((k, v) in ok) if (now - v < TTL) o.put(k, v)
        Store.saveAlive(o.toString())
    }

    fun clear() {
        ok.clear(); bad.clear(); soft.clear()
        Store.saveAlive("{}")
    }

    fun status(u: String): Boolean? {
        val now = System.currentTimeMillis()
        val a = ok[u]
        if (a != null && now - a < TTL) return true
        val b = bad[u]
        if (b != null && now - b < BAD_TTL) return false
        return null
    }

    fun isOk(u: String): Boolean {
        val a = ok[u]
        return a != null && System.currentTimeMillis() - a < TTL
    }

    fun mark(u: String, alive: Boolean) {
        val now = System.currentTimeMillis()
        if (alive) {
            ok[u] = now; bad.remove(u); soft.remove(u)
        } else if (ok.containsKey(u) && !soft.containsKey(u)) {
            // a link that worked before survives its first miss and is re-checked soon
            soft[u] = true
            ok[u] = now - TTL + BAD_TTL
        } else {
            ok.remove(u); bad[u] = now
        }
    }
}

object Prober {
    suspend fun isAlive(url: String): Boolean {
        val known = AliveCache.status(url)
        if (known != null) return known
        if (!Net.online()) return false
        val r = withContext(Dispatchers.IO) { try { deep(url) } catch (e: Exception) { false } }
        AliveCache.mark(url, r)
        return r
    }

    /** Works only if the playlist AND the first video piece can really be downloaded. */
    private fun deep(start: String): Boolean {
        var cur = start
        for (i in 0 until 3) {
            val body = Net.getBytes(cur, 300_000) ?: return false
            val text = String(body, Charsets.UTF_8)
            if (!text.trimStart().startsWith("#EXTM3U")) return false
            val line = text.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: return false
            val next = URL(URL(cur), line).toString()
            if (text.contains("#EXT-X-STREAM-INF")) {
                cur = next
                continue
            }
            val seg = Net.getBytes(next, 1024) ?: return false
            return seg.isNotEmpty()
        }
        return false
    }
}

/* -------------------------------------------------------------- view model */

class PreSlot(val channel: Channel, val player: ExoPlayer, val url: String) {
    var ready = false
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    // ---- list state
    var tabs by mutableStateOf<List<Tab>>(emptyList())
    var currentTab by mutableStateOf("bd")
    var status by mutableStateOf("Loading…")
    var query by mutableStateOf("")
    var fast by mutableStateOf(true)
    val visible = mutableStateListOf<Channel>()
    private val visIdx = mutableListOf<Int>()
    private var tabJob: Job? = null

    // ---- player state
    var player by mutableStateOf<ExoPlayer?>(null)
    var playingChannel by mutableStateOf<Channel?>(null)
    var playStatus by mutableStateOf("")
    var overlay by mutableStateOf(true)
    var overlayTick by mutableStateOf(0)
    var qualities by mutableStateOf(listOf(-1))
    var selectedQ by mutableStateOf(-1)
    var toast by mutableStateOf("")

    private var main: ExoPlayer? = null
    private var preSlot: PreSlot? = null
    private var curCh: Channel? = null
    private var queue = ArrayDeque<String>()
    private var ready = false
    private var startAt = 0L
    private var lastDir = 1
    private var zapTarget: Channel? = null
    private val handler = Handler(Looper.getMainLooper())
    private val PLAY_WAIT = 22_000L

    init {
        Net.app = app
        Store.init(app)
        AliveCache.restore()
        fast = Store.fast
        load(false)
    }

    // ------------------------------------------------------------ channel lists

    fun load(force: Boolean) {
        viewModelScope.launch {
            if (force) {
                AliveCache.clear()
                Store.clearHidden()
            }
            status = "Loading channel lists…"
            val t: List<Tab> = try {
                Repo.loadTabs(getApplication<Application>(), force)
            } catch (e: Exception) {
                emptyList<Tab>()
            }
            tabs = t
            if (t.isEmpty()) {
                visible.clear(); visIdx.clear()
                status = "Could not load the lists. Check the internet and press Refresh."
                return@launch
            }
            if (currentTab != "mine" && t.none { it.id == currentTab }) currentTab = t[0].id
            selectTab(currentTab)
        }
    }

    fun toggleFast() {
        fast = !fast
        Store.fast = fast
        if (!fast) killPre()
    }

    private fun insertVisible(idx: Int, c: Channel) {
        var pos = visIdx.indexOfFirst { it > idx }
        if (pos < 0) pos = visIdx.size
        visIdx.add(pos, idx)
        visible.add(pos, c)
    }

    private fun removeVisible(c: Channel) {
        val i = visible.indexOf(c)
        if (i >= 0) {
            visible.removeAt(i)
            visIdx.removeAt(i)
        }
    }

    private suspend fun loadMine(): List<Channel> = withContext(Dispatchers.IO) {
        val out = ArrayList<Channel>()
        for (cu in Store.customs()) {
            if (cu.type == "stream") {
                out.add(Channel(if (cu.name.isBlank()) "My channel" else cu.name, "", listOf(cu.url), true, true, cu.url))
            } else {
                try {
                    for (r in parseM3u(Net.getString(cu.url))) out.add(Channel(r.name, r.logo, r.urls, true, true, cu.url))
                } catch (e: Exception) { }
            }
        }
        out
    }

    fun selectTab(id: String) {
        currentTab = id
        tabJob?.cancel()
        visible.clear()
        visIdx.clear()
        tabJob = viewModelScope.launch {
            val items: List<Channel> = if (id == "mine") loadMine() else (tabs.firstOrNull { it.id == id }?.channels ?: emptyList())
            val candidates = items.filter { !Store.isHidden(norm(it.name)) }
            val total = candidates.size
            var found = 0
            var done = 0
            status = if (total == 0) "Nothing here yet." else "Checking channels… 0 working"
            val next = AtomicInteger(0)
            coroutineScope {
                for (w in 0 until 8) {
                    launch(Dispatchers.IO) {
                        while (isActive) {
                            val i = next.getAndIncrement()
                            if (i >= total) break
                            val c = candidates[i]
                            var ok = c.verified
                            if (!ok) {
                                for (u in c.urls) {
                                    if (Prober.isAlive(u)) { ok = true; break }
                                }
                            }
                            withContext(Dispatchers.Main) {
                                done++
                                if (ok && found < 800) { found++; insertVisible(i, c) }
                                status = if (done < total) "Checking channels… $found working" else summary(found)
                            }
                        }
                    }
                }
            }
            if (total > 0) status = summary(found)
            AliveCache.persist()
        }
    }

    private fun summary(found: Int): String = when {
        found > 0 -> "$found working channels"
        !Net.online() -> "No internet connection. Connect and press Refresh."
        else -> "No working channels found. Press Refresh and try again."
    }

    fun addCustom(name: String, url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            var type = if (url.contains(".m3u8", ignoreCase = true)) "stream" else "list"
            try {
                val t = Net.getString(url)
                type = if (t.contains("#EXT-X-")) "stream" else "list"
            } catch (e: Exception) { }
            Store.addCustom(Custom(name, url, type))
            withContext(Dispatchers.Main) { selectTab("mine") }
        }
    }

    fun removeCustom(src: String) {
        Store.removeCustom(src)
        selectTab("mine")
    }

    // ------------------------------------------------------------------ player

    private fun newPlayer(): ExoPlayer {
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(5_000, 15_000, 1_000, 2_000)
            .build()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 11) Vimline")
            .setConnectTimeoutMs(8_000)
            .setReadTimeoutMs(10_000)
            .setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(getApplication<Application>())
            .setLoadControl(lc)
            .setMediaSourceFactory(DefaultMediaSourceFactory(getApplication<Application>()).setDataSourceFactory(http))
            .build()
        p.addListener(listener(p))
        return p
    }

    private fun item(url: String): MediaItem =
        MediaItem.Builder().setUri(url).setMimeType(MimeTypes.APPLICATION_M3U8).build()

    private fun listener(p: ExoPlayer): Player.Listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state != Player.STATE_READY) return
            if (p === main) {
                if (!ready) {
                    ready = true
                    handler.removeCallbacks(timeout)
                    playStatus = "Live"
                    afterLive()
                }
            } else {
                val s = preSlot
                if (s != null && s.player === p) s.ready = true
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (p === main) {
                handler.removeCallbacks(timeout)
                if (ready) {
                    ready = false
                    startAt = SystemClock.elapsedRealtime()
                    queue = ArrayDeque(curCh?.urls ?: emptyList())
                }
                attempt()
            } else {
                val s = preSlot
                if (s != null && s.player === p) killPre()
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            if (p === main) updateQualities(p)
        }
    }

    private val timeout = Runnable { if (!ready) attempt() }

    fun openChannel(c: Channel) {
        lastDir = 1
        playNow(c)
    }

    private fun showOverlay() {
        overlay = true
        overlayTick++
    }

    fun toggleOverlay() {
        overlay = !overlay
        if (overlay) overlayTick++
    }

    private fun playNow(c: Channel) {
        curCh = c
        playingChannel = c
        startAt = SystemClock.elapsedRealtime()
        ready = false
        qualities = listOf(-1)
        selectedQ = -1
        queue = ArrayDeque(c.urls.sortedByDescending { if (AliveCache.isOk(it)) 1 else 0 })
        showOverlay()
        val s = preSlot
        if (s != null && s.channel === c) promote(s) else {
            killPre()
            attempt()
        }
    }

    private fun attempt() {
        val c = curCh ?: return
        val left = PLAY_WAIT - (SystemClock.elapsedRealtime() - startAt)
        val url = if (left > 1_500) queue.removeFirstOrNull() else null
        if (url == null) {
            giveUp(c)
            return
        }
        playStatus = "Starting…"
        var p = main
        if (p == null) {
            p = newPlayer()
            main = p
            player = p
        }
        p.setMediaItem(item(url))
        p.prepare()
        p.playWhenReady = true
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, if (queue.isEmpty()) left else minOf(12_000L, left))
    }

    private fun giveUp(c: Channel) {
        if (!Net.online()) {
            playStatus = "Network problem. Select the channel again to retry."
            return
        }
        if (c.mine) {
            playStatus = "Not working right now."
            return
        }
        Store.hide(norm(c.name))
        removeVisible(c)
        playStatus = "Not working. Hidden for 1 hour."
    }

    private fun afterLive() {
        val c = curCh ?: return
        val list = visible.toList()
        val i = list.indexOf(c)
        if (!fast || i < 0 || list.size < 2) return
        startPre(list[(i + lastDir + list.size) % list.size])
    }

    private fun startPre(c: Channel) {
        val cur = preSlot
        if (cur != null && cur.channel === c) return
        killPre()
        val url = c.urls.sortedByDescending { if (AliveCache.isOk(it)) 1 else 0 }.firstOrNull() ?: return
        val p = newPlayer()
        val s = PreSlot(c, p, url)
        preSlot = s
        p.setMediaItem(item(url))
        p.playWhenReady = false
        p.prepare()
    }

    private fun killPre() {
        preSlot?.player?.release()
        preSlot = null
    }

    private fun promote(s: PreSlot) {
        preSlot = null
        val old = main
        main = s.player
        player = s.player
        old?.release()
        queue.remove(s.url)
        s.player.playWhenReady = true
        if (s.ready) {
            ready = true
            playStatus = "Live"
            updateQualities(s.player)
            afterLive()
        } else {
            playStatus = "Starting…"
            handler.removeCallbacks(timeout)
            handler.postDelayed(timeout, PLAY_WAIT)
        }
    }

    fun zap(d: Int) {
        val list = visible.toList()
        if (list.isEmpty()) return
        lastDir = if (d > 0) 1 else -1
        val from = zapTarget ?: playingChannel
        var i = if (from == null) 0 else list.indexOf(from)
        if (i < 0) i = 0
        val n = list[(i + d + list.size) % list.size]
        zapTarget = n
        playingChannel = n
        playStatus = "…"
        showOverlay()
        handler.removeCallbacks(zapRun)
        zapRun = Runnable {
            zapTarget = null
            playNow(n)
        }
        val s = preSlot
        if (s != null && s.channel === n && s.ready) zapRun.run() else handler.postDelayed(zapRun, 300)
    }

    private var zapRun = Runnable { }

    // ----------------------------------------------------------------- quality

    private fun updateQualities(p: ExoPlayer) {
        val hs = ArrayList<Int>()
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                val h = g.getTrackFormat(i).height
                if (h > 0 && !hs.contains(h)) hs.add(h)
            }
        }
        hs.sortDescending()
        qualities = listOf(-1) + hs
    }

    fun setQuality(h: Int) {
        val p = main ?: return
        val b = p.trackSelectionParameters.buildUpon()
        if (h < 0) {
            b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
        } else {
            for (g in p.currentTracks.groups) {
                if (g.type != C.TRACK_TYPE_VIDEO) continue
                for (i in 0 until g.length) {
                    if (g.isTrackSupported(i) && g.getTrackFormat(i).height == h) {
                        b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                        break
                    }
                }
            }
        }
        p.trackSelectionParameters = b.build()
        selectedQ = h
    }

    fun cycleQuality(d: Int) {
        if (qualities.size < 2) {
            flash("Only one quality available")
            return
        }
        val i = qualities.indexOf(selectedQ).let { if (it < 0) 0 else it }
        val h = qualities[(i + d + qualities.size) % qualities.size]
        setQuality(h)
        flash("Quality: " + if (h < 0) "Auto" else "${h}p")
    }

    private fun flash(t: String) {
        toast = t
        handler.removeCallbacks(clearToast)
        handler.postDelayed(clearToast, 1_800)
    }

    private val clearToast = Runnable { toast = "" }

    fun closePlayer() {
        handler.removeCallbacks(timeout)
        handler.removeCallbacks(zapRun)
        zapTarget = null
        killPre()
        main?.release()
        main = null
        player = null
        playingChannel = null
        curCh = null
    }

    override fun onCleared() {
        closePlayer()
        super.onCleared()
    }
}
